public interface InterfaceCelular {
    public void ligarTela();
    public String getData();
    public String getHora();
    public void desbloquear();
    public void setSenha();
    public String getMensagensRecebidas();
    public void setMusica(String caminhoMusica);
    public void setReceberMensagem(String mensagemRecebida);
    public void mandarMensagem(int codigoarea, int numero, String textoAEnviar);
    public void tocarMusica();
}
