
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;
public class Celular implements InterfaceCelular{
    private boolean bloqueio, internet;
    private LocalDate data;
    private LocalTime hora;
    private String senha , musica , mensagens;
    private Scanner input;
    private File arqvmusica;
    @Override
    public void ligarTela(){
        if(bloqueio){
            System.out.println(getHora());
            System.out.println(getData());
            System.out.println(getMensagensRecebidas());
            if(internet){
                System.out.println("Conectado à internet");
                }else{
                    System.out.println("Sem conexão à internet");
                }
            }
        else{
            System.out.println(getHora());
            System.out.println(getData());
            if(internet){
                System.out.println("Conectado à internet");
                }else{
                    System.out.println("Sem conexão à internet");
                }
            }
        }
    @Override
    public String getData(){
        data = LocalDate.now();
        return String.valueOf(data);
    }
    @Override
    public String getHora(){
        hora = LocalTime.now();
        return String.valueOf(hora);
    }
    @Override
    public void desbloquear(){
        if(senha.equals("")){
            bloqueio = true;
            
        }else{
            int i;
            System.out.println("Digite a Senha para desbloquear:");
            for(i=0;i<5;i++){
            if(senha.equals(input.nextLine())){
                bloqueio = true;
                return;
                }
                System.out.println("Senha incorreta.\nTente novamente: ");
            }
            System.out.println("Tentativas excedidas.");
        }
    }
    @Override
    public void setSenha(){
            if(bloqueio){
            int i;
            if(senha.equals("")){
                System.out.println("Insira a nova senha");
                senha = input.nextLine();
            }else{
                System.out.println("digite a senha anterior para definir uma nova:");
                for(i=0;i<5;i++){

                if( senha.equals(input.nextLine())){
                    System.out.println("Insira a nova senha: ");
                    senha = input.nextLine();
                    System.out.println("Senha alterada");
                    return;
                    }
                System.out.println("Senha incorreta\nTente novamente: ");
                }
                System.out.println("Numero de tentativas excedido.");
            }
        }
    }
    @Override
    public void setReceberMensagem(String mensagemRecebida){
        mensagens+=mensagemRecebida+"\n";
    }
    @Override
    public String getMensagensRecebidas(){
        if(bloqueio){
        return mensagens;
        }
        return "Acesso negado";
    }
    @Override
    public void mandarMensagem(int codigoarea, int numero , String textoAEnviar){
        if(bloqueio){
            if(internet){
                System.out.println("Enviando...\nMensagem enviada para: "+codigoarea+numero+"\nCorpo da mensagem:\n"+textoAEnviar);
            }else{
                System.out.println("Não foi possível enviar a mensagem.\nSem conexão à internet.");
            }
        }
    }
    @Override
    public void setMusica(String caminhoMusica){
        if(bloqueio){
        musica = caminhoMusica;
        }
    }
    @Override
    public void tocarMusica(){
        if(bloqueio){
            arqvmusica = new File(musica);
            try {
                Desktop.getDesktop().open(arqvmusica);
            } catch (IOException e){
                System.out.println("Não é possível tocar essa música");
            }
        }
    }
public Celular(boolean conectado){
    internet = conectado;
    mensagens = "";
    musica = "";
    bloqueio = false;
    senha = "";
    input = new Scanner(System.in);
    }
}